import requests
import csv
import os

medicos = []
id_medico = len(medicos)
url = f'https://randomuser.me/api/?results=10&inc=id,dni,name,phone,email,location,login&password=number,6-6'
ruta_archivo_medicos = "modelos/medicos.csv"

def inicializar_medicos():
    if os.path.exists(ruta_archivo_medicos):
        importar_datos_desde_csv()


def obtener_datos_desde_api():
    response = requests.get(url)
    datos = response.json()
    
    for result in datos.get('results', []):
        password = result["login"]["password"]
        hashdni = sum(ord(char) for char in password)

    for result in datos.get('results', []):
        medico = {
            "id": len(medicos) + 1,
            "dni": hashdni,
            "nombre": result["name"]["first"],
            "apellido": result["name"]["last"],
            "matricula": result["login"]["password"],
            "telefono": result["phone"],
            "email": result["email"],
            "habilitado": True,
        }
        medicos.append(medico)
    
    with open(ruta_archivo_medicos, 'w', newline='', encoding='utf-8') as archivo_csv:
        fieldnames = ["id", "dni", "nombre", "apellido", "matricula", "telefono", "email", "habilitado"]
        writer = csv.DictWriter(archivo_csv, fieldnames=fieldnames)
        
        if archivo_csv.tell() == 0:
            writer.writeheader()

        for medico in medicos:
            writer.writerow(medico)
    
    return medicos

def ingresar_medico(dni, nombre, apellido, matricula, telefono, email, habilitado):
    medicos.append({
            "id" : id_medico + 1,
            "dni" : dni,
            "nombre" : nombre,
            "apellido" : apellido,
            "matricula" : matricula,
            "telefono" : telefono,
            "email" : email,
            "habilitado" : habilitado,
        })
    exportar_a_csv()
    return medicos[-1]

def exportar_a_csv():
    with open(ruta_archivo_medicos, 'w', newline='', encoding="utf8") as csvfile:
        campos = ["id", "dni", "nombre", "apellido", "matricula", "telefono", "email", "habilitado"]
        writer = csv.DictWriter(csvfile, fieldnames=campos)
        writer.writeheader()
        for medico in medicos:
            writer.writerow(medico)
    
def importar_datos_desde_csv():
    global medicos
    medicos = []  
    with open(ruta_archivo_medicos, newline='', encoding="utf8") as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            row['id'] = int(row['id'])
            medicos.append(row)

