from flask import Flask
from modelos.agenda_medicos import inicializar_agenda
from modelos.turnos import incializar_turnos
from modelos.medicos import inicializar_medicos
from controladores.pacientes_controller import pacientes_blueprint
from controladores.agenda_contoller import agenda_bp
from controladores.turnos_controller import turnos_bp
from controladores.medicos_controller import medicos_blueprint

app = Flask(__name__)

inicializar_agenda()
incializar_turnos()
inicializar_medicos()

app.register_blueprint(agenda_bp)
app.register_blueprint(pacientes_blueprint)
app.register_blueprint(turnos_bp)
app.register_blueprint(medicos_blueprint)
# app.register_blueprint(pacientes_blueprint, url_prefix='/pacientes')

if __name__ == '__main__':
    app.run(debug=True)