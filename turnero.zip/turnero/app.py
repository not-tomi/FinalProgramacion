from flask import Flask
from modelos.agenda_medicos import inicializar_agenda
from controladores.rutas_agenda_medicos import agenda_bp

app = Flask(__name__)

inicializar_agenda()

app.register_blueprint(agenda_bp)

if __name__ == '__main__':
    app.run(debug=True)